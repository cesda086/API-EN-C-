﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.Data
{
    public class Conexion
    {
        public static string rutaConexion = "Data Source=.;Initial Catalog=DBPRUEBAS;Integrated Security=True";
    }
}